// Framtida interaktion kan läggas här
console.log("MayaVäskor – Hantverk med själ");
